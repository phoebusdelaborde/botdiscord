process.on("unhandledRejection", (reason, promise) => { console.log("Unhandled Rejection:", reason);});
process.on("uncaughtException", (err) => { console.log("Uncaught Exception:", err); }); 
const { Client, IntentsBitField, Collection } = require("discord.js");
const client = new Client({ intents: new IntentsBitField(3276799) });
const loadCommands = require("./loaders/loadCommands"); 
const dotenv = require("dotenv"); dotenv.config(); client.commands = new Collection(); loadCommands(client); // Vérification toutes les 5 minutes
client.on("messageCreate", message => { 
    const prefix = "!";
    if (!message.content.startsWith(prefix)) return; 
    const name = message.content.split(" ")[0].slice(prefix.length, message.content.split(" ")[0].length);
    const command = client.commands.get(name);
    if (!command) return; // 🔒 Restriction aux rôles "Admin" et "Développeur" sans message
    if (!message.member.roles.cache.some(role => ["Admin", "Développeur"].includes(role.name))) return;
    if(!client.commands.get(name)) return; command.run(client, message); 
}); 
client.login(process.env.TOKEN);