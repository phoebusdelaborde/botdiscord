const Parser = require("rss-parser");
const parser = new Parser();

const CHANNEL_ID = "UC3iYd0E930lemCQUWIInOlg";
const ROLE_ID = "1439569755332808796";
const FEED_URL = `https://www.youtube.com/feeds/videos.xml?channel_id=${CHANNEL_ID}`;

// Variables au niveau du module : partagées entre tous les appels de la commande
let interval = null;          // empêche de créer plusieurs boucles
let checking = false;         // empêche deux vérifications simultanées
const announced = new Set();  // IDs des vidéos déjà annoncées

async function fetchFeed() {
    const feed = await parser.parseURL(FEED_URL);
    if (!feed || !feed.items || feed.items.length === 0) return null;
    return feed.items;
}

module.exports = {
    name: "regardenouvellevideo",
    async run(client, message) {
        const channel = message.channel;
        message.delete().catch(() => {});

        // Boucle déjà active : on n'en crée pas une deuxième
        if (interval) {
            return channel.send("La surveillance des vidéos est déjà active.");
        }

        // Enregistrer toutes les vidéos actuelles comme "déjà vues"
        let items;
        try {
            items = await fetchFeed();
        } catch (err) {
            console.error("Erreur flux YouTube :", err.message);
        }
        if (!items) {
            return channel.send("Impossible de lire le flux YouTube...");
        }
        for (const item of items) announced.add(item.id || item.link);

        interval = setInterval(async () => {
            if (checking) return;
            checking = true;

            try {
                const current = await fetchFeed();
                if (!current) return;

                // Du plus ancien au plus récent
                for (const video of [...current].reverse()) {
                    const id = video.id || video.link;
                    if (announced.has(id)) continue;

                    announced.add(id); // AVANT l'envoi, pour éviter tout doublon

                    await channel.send({
                        content: `<@&${ROLE_ID}> **Nouvelle vidéo publiée !!! :**\n**${video.title}**\n${video.link}`
                    });
                }
            } catch (err) {
                console.error("Erreur pendant la vérification :", err.message);
            } finally {
                checking = false;
            }
        }, 60000);

        channel.send("Surveillance des nouvelles vidéos activée.");
    }
};const Parser = require("rss-parser");
const parser = new Parser();

const CHANNEL_ID = "UC3iYd0E930lemCQUWIInOlg";
const ROLE_ID = "1439569755332808796";
const FEED_URL = `https://www.youtube.com/feeds/videos.xml?channel_id=${CHANNEL_ID}`;

// Variables au niveau du module : partagées entre tous les appels de la commande
let interval = null;          // empêche de créer plusieurs boucles
let checking = false;         // empêche deux vérifications simultanées
const announced = new Set();  // IDs des vidéos déjà annoncées

async function fetchFeed() {
    const feed = await parser.parseURL(FEED_URL);
    if (!feed || !feed.items || feed.items.length === 0) return null;
    return feed.items;
}

module.exports = {
    name: "regardenouvellevideo",
    async run(client, message) {
        const channel = message.channel;
        message.delete().catch(() => {});

        // Boucle déjà active : on n'en crée pas une deuxième
        if (interval) {
            return channel.send("La surveillance des vidéos est déjà active.");
        }

        // Enregistrer toutes les vidéos actuelles comme "déjà vues"
        let items;
        try {
            items = await fetchFeed();
        } catch (err) {
            console.error("Erreur flux YouTube :", err.message);
        }
        if (!items) {
            return channel.send("Impossible de lire le flux YouTube...");
        }
        for (const item of items) announced.add(item.id || item.link);

        interval = setInterval(async () => {
            if (checking) return;
            checking = true;

            try {
                const current = await fetchFeed();
                if (!current) return;

                // Du plus ancien au plus récent
                for (const video of [...current].reverse()) {
                    const id = video.id || video.link;
                    if (announced.has(id)) continue;

                    announced.add(id); // AVANT l'envoi, pour éviter tout doublon

                    await channel.send({
                        content: `<@&${ROLE_ID}> **Nouvelle vidéo publiée !!! :**\n**${video.title}**\n${video.link}`
                    });
                }
            } catch (err) {
                console.error("Erreur pendant la vérification :", err.message);
            } finally {
                checking = false;
            }
        }, 60000);

        channel.send("Surveillance des nouvelles vidéos activée.");
    }
};