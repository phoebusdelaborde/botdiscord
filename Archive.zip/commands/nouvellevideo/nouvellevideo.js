const Parser = require("rss-parser");
const parser = new Parser();

module.exports = {
    name: "nouvellevideo",
    async run(client, message) {
        const channelId = "UC3iYd0E930lemCQUWIInOlg"; // ID chaîne
        const feed = await parser.parseURL(`https://www.youtube.com/feeds/videos.xml?channel_id=${channelId}`);
        const lastVideo = feed.items[0];

        message.channel.send({
            content: `<@&1439569755332808796> **Nouvelle vidéo publiée !!! :**\n**${lastVideo.title}**\n${lastVideo.link} `
        });
        message.delete()
    }
}
