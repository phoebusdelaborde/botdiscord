module.exports = {
    name : "video",
    async run(client, message){
        message.channel.send("<@&1439569755332808796> Nouvelle Video !!! " + message.content.split(" ")[1])
        message.delete()
    }
}