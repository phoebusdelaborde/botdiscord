module.exports = {
    name: "countdown",
    async run(client, message) {
        let countdown = parseInt(message.content.split(" ")[1]);
        let chanel = message.channel
        if (isNaN(countdown)) return message.reply("Donne un nombre !");
        await message.delete()
        const msg = await chanel.send("Il reste " + countdown + " secondes");

        // mise à jour du message
        for (let i = countdown; i >= 0; i--) {
            setTimeout(() => {
                msg.edit("Il reste " + i + " secondes");
            }, 1000 * (countdown - i)); 
        }

        // ⏳ supprimer et envoyer "Il est temps" APRÈS le countdown
        setTimeout(async () => {
            await msg.delete();
            await chanel.send("Il est temps");
        }, (countdown + 1) * 1000); // +1 pour afficher le "0 seconde"
    }
}
