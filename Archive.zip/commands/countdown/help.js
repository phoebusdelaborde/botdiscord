module.exports = {
    name:"help",
    async run(client, message) {
        message.channel.send(' >   **Tous les commands :** \n'+
 '>         `!countdown (time sec) `: **met un count a reboure**\n'+
' >         `!nouvellevideo` : **montre la nouvelle video**\n'+
' >         `!video (url de la video) `: **montre la video**\n'+
' >         `!regardenouvellevideo `: **met la derniere video**'
            )
            message.delete()
    }

}